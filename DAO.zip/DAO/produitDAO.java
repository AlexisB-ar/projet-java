package DAO;

import model.Produit;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class produitDAO {

    private Connection connection;

    public produitDAO(Connection connection) {
        this.connection = connection;
    }

    public List<Produit> getAllProduits() {
        List<Produit> produits = new ArrayList<>();

        String sql = "SELECT * FROM produit";

        try (PreparedStatement stmt = connection.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Produit p = new Produit(
                        rs.getInt("idProduit"),
                        rs.getString("libelle"),
                        rs.getString("description"),
                        rs.getDate("dateSortie").toLocalDate(),
                        rs.getString("typeProduit"),
                        rs.getInt("dureeMoyenne"),
                        rs.getInt("stockDispo"),
                        rs.getDouble("prixAchat"),
                        rs.getDouble("prixLocation")
                );
                produits.add(p);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return produits;
    }
}
