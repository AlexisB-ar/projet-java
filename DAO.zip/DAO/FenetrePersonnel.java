package DAO;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.Vector;

public class FenetrePersonnel extends JFrame implements ActionListener {

    private JComboBox<Integer> cbEntreprise;
    private JComboBox<Integer> cbEquipe;
    private JTable table;
    private DefaultTableModel tableModel;

    private JButton btnAjouter, btnModifier, btnSupprimer;

    private Connection cnx;

    public FenetrePersonnel() {
        setTitle("Consultation du personnel");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 500);
        setLocationRelativeTo(null);

        connecterBDD();

        cbEntreprise = new JComboBox<>();
        cbEquipe = new JComboBox<>();

        cbEntreprise.addItem(null);
        cbEquipe.addItem(null);

        cbEntreprise.addActionListener(this);
        cbEquipe.addActionListener(this);

        JPanel panelHaut = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panelHaut.add(new JLabel("Entreprise :"));
        panelHaut.add(cbEntreprise);
        panelHaut.add(new JLabel("Équipe :"));
        panelHaut.add(cbEquipe);

        tableModel = new DefaultTableModel(new String[]{"ID", "Nom", "Prénom"}, 0);
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);

        btnAjouter = new JButton("Ajouter");
        btnModifier = new JButton("Modifier");
        btnSupprimer = new JButton("Supprimer");

        btnAjouter.addActionListener(this);
        btnModifier.addActionListener(this);
        btnSupprimer.addActionListener(this);

        JPanel panelBoutons = new JPanel();
        panelBoutons.add(btnAjouter);
        panelBoutons.add(btnModifier);
        panelBoutons.add(btnSupprimer);

        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(panelHaut, BorderLayout.NORTH);
        getContentPane().add(scrollPane, BorderLayout.CENTER);
        getContentPane().add(panelBoutons, BorderLayout.SOUTH);

        chargerEntreprises();

        setVisible(true);
    }

    private void connecterBDD() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            cnx = DriverManager.getConnection(
                    "jdbc:mysql://localhost:8889/calendrierTT?serverTimezone=UTC",
                    "root",
                    "root"
            );

            System.out.println("Connexion réussie !");
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this,
                    "Erreur de connexion : " + e.getMessage(),
                    "Erreur",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void chargerEntreprises() {
        if (cnx == null) return;

        cbEntreprise.removeAllItems();
        cbEntreprise.addItem(null);

        String sql = "SELECT DISTINCT id_entreprise FROM personne ORDER BY id_entreprise";

        try (Statement st = cnx.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                cbEntreprise.addItem(rs.getInt("id_entreprise"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        cbEquipe.removeAllItems();
        cbEquipe.addItem(null);
        tableModel.setRowCount(0);
    }

    private void chargerEquipesPourEntreprise(Integer idEntreprise) {
        if (cnx == null || idEntreprise == null) return;

        cbEquipe.removeAllItems();
        cbEquipe.addItem(null);

        String sql = "SELECT DISTINCT id_equipe FROM personne WHERE id_entreprise = ? ORDER BY id_equipe";

        try (PreparedStatement ps = cnx.prepareStatement(sql)) {
            ps.setInt(1, idEntreprise);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    cbEquipe.addItem(rs.getInt("id_equipe"));
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        tableModel.setRowCount(0);
    }

    private void chargerPersonnes(Integer idEntreprise, Integer idEquipe) {
        if (cnx == null || idEntreprise == null || idEquipe == null) return;

        tableModel.setRowCount(0);

        String sql = "SELECT id_personne, nom, prenom FROM personne " +
                "WHERE id_entreprise = ? AND id_equipe = ? ORDER BY nom, prenom";

        try (PreparedStatement ps = cnx.prepareStatement(sql)) {
            ps.setInt(1, idEntreprise);
            ps.setInt(2, idEquipe);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Vector<Object> ligne = new Vector<>();
                    ligne.add(rs.getInt("id_personne"));
                    ligne.add(rs.getString("nom"));
                    ligne.add(rs.getString("prenom"));
                    tableModel.addRow(ligne);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void ajouterPersonne() {
        JTextField tfNom = new JTextField();
        JTextField tfPrenom = new JTextField();
        JTextField tfEntreprise = new JTextField();
        JTextField tfEquipe = new JTextField();

        Object[] message = {
                "Nom :", tfNom,
                "Prénom :", tfPrenom,
                "ID Entreprise :", tfEntreprise,
                "ID Équipe :", tfEquipe
        };

        int option = JOptionPane.showConfirmDialog(this, message, "Ajouter une personne", JOptionPane.OK_CANCEL_OPTION);

        if (option == JOptionPane.OK_OPTION) {
            try {
                String sql = "INSERT INTO personne (nom, prenom, id_entreprise, id_equipe) VALUES (?, ?, ?, ?)";
                PreparedStatement ps = cnx.prepareStatement(sql);
                ps.setString(1, tfNom.getText());
                ps.setString(2, tfPrenom.getText());
                ps.setInt(3, Integer.parseInt(tfEntreprise.getText()));
                ps.setInt(4, Integer.parseInt(tfEquipe.getText()));
                ps.executeUpdate();

                JOptionPane.showMessageDialog(this, "Personne ajoutée !");
                chargerEntreprises();

            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Erreur : " + e.getMessage());
            }
        }
    }

    private void modifierPersonne() {
        int row = table.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Sélectionnez une personne.");
            return;
        }

        int id = (int) tableModel.getValueAt(row, 0);
        String nom = (String) tableModel.getValueAt(row, 1);
        String prenom = (String) tableModel.getValueAt(row, 2);

        JTextField tfNom = new JTextField(nom);
        JTextField tfPrenom = new JTextField(prenom);

        Object[] message = {
                "Nom :", tfNom,
                "Prénom :", tfPrenom
        };

        int option = JOptionPane.showConfirmDialog(this, message, "Modifier la personne", JOptionPane.OK_CANCEL_OPTION);

        if (option == JOptionPane.OK_OPTION) {
            try {
                String sql = "UPDATE personne SET nom = ?, prenom = ? WHERE id_personne = ?";
                PreparedStatement ps = cnx.prepareStatement(sql);
                ps.setString(1, tfNom.getText());
                ps.setString(2, tfPrenom.getText());
                ps.setInt(3, id);
                ps.executeUpdate();

                JOptionPane.showMessageDialog(this, "Modification réussie !");
                Integer idEnt = (Integer) cbEntreprise.getSelectedItem();
                Integer idEq = (Integer) cbEquipe.getSelectedItem();
                chargerPersonnes(idEnt, idEq);

            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Erreur : " + e.getMessage());
            }
        }
    }

    private void supprimerPersonne() {
        int row = table.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Sélectionnez une personne.");
            return;
        }

        int id = (int) tableModel.getValueAt(row, 0);

        int confirm = JOptionPane.showConfirmDialog(this,
                "Supprimer cette personne ?", "Confirmation",
                JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            try {
                String sql = "DELETE FROM personne WHERE id_personne = ?";
                PreparedStatement ps = cnx.prepareStatement(sql);
                ps.setInt(1, id);
                ps.executeUpdate();

                JOptionPane.showMessageDialog(this, "Personne supprimée !");
                Integer idEnt = (Integer) cbEntreprise.getSelectedItem();
                Integer idEq = (Integer) cbEquipe.getSelectedItem();
                chargerPersonnes(idEnt, idEq);

            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Erreur : " + e.getMessage());
            }
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object src = e.getSource();

        if (src == cbEntreprise) {
            Integer idEnt = (Integer) cbEntreprise.getSelectedItem();
            if (idEnt != null) chargerEquipesPourEntreprise(idEnt);
            else {
                cbEquipe.removeAllItems();
                cbEquipe.addItem(null);
                tableModel.setRowCount(0);
            }
        }
        else if (src == cbEquipe) {
            Integer idEnt = (Integer) cbEntreprise.getSelectedItem();
            Integer idEq = (Integer) cbEquipe.getSelectedItem();
            if (idEnt != null && idEq != null) chargerPersonnes(idEnt, idEq);
            else tableModel.setRowCount(0);
        }
        else if (src == btnAjouter) ajouterPersonne();
        else if (src == btnModifier) modifierPersonne();
        else if (src == btnSupprimer) supprimerPersonne();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(FenetrePersonnel::new);
    }
}
