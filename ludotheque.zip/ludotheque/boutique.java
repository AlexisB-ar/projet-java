package ludotheque;

import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.util.ArrayList;

public class boutique extends JPanel {

    private JComboBox<String> typeSelector;
    private JPanel cardsPanel;

    private int nbPanier = 0;
    private JLabel panierLabel;

    private double argent = 50.0;
    private double totalPanier = 0.0;
    private JLabel argentLabel;

    public boutique() {

        setLayout(new BorderLayout());

        // --- PANEL GLOBAL AVEC ENCADRÉ ---
        JPanel panelBoutique = new JPanel(new BorderLayout());
        panelBoutique.setBorder(BorderFactory.createTitledBorder("Ludothèque - Catalogue"));
        add(panelBoutique, BorderLayout.CENTER);

        // --- SELECTEUR DE TYPE ---
        JPanel topPanel = new JPanel();
        topPanel.add(new JLabel("Catégorie : "));

        typeSelector = new JComboBox<>(new String[]{"Livre", "Jeu vidéo", "Jeu société"});
        typeSelector.addActionListener(e -> chargerCartes());
        topPanel.add(typeSelector);



        // --- PANEL DU HAUT ---
        JPanel header = new JPanel();
        header.setLayout(new BoxLayout(header, BoxLayout.Y_AXIS));
        header.add(topPanel);

        panelBoutique.add(header, BorderLayout.NORTH);

        // --- PANEL DES CARTES ---
        cardsPanel = new JPanel();
        cardsPanel.setLayout(new GridLayout(0, 3, 20, 20));
        cardsPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JScrollPane scroll = new JScrollPane(cardsPanel);
        panelBoutique.add(scroll, BorderLayout.CENTER);

        // --- PANIER ---
        panierLabel = new JLabel("Panier : 0 article(s) | Total : 0€");
        panierLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));

        argentLabel = new JLabel("Argent : " + argent + "€");
        argentLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));

        JButton boutonAcheterPanier = new JButton("Acheter");
        boutonAcheterPanier.setFont(new Font("Segoe UI", Font.PLAIN, 14));

        boutonAcheterPanier.addActionListener(e -> {
            if (nbPanier == 0) {
                JOptionPane.showMessageDialog(this, "Votre panier est vide !");
                return;
            }

            if (argent < totalPanier) {
                JOptionPane.showMessageDialog(this, "Vous n'avez pas assez d'argent !");
                return;
            }

            argent -= totalPanier;
            nbPanier = 0;
            totalPanier = 0;

            panierLabel.setText("Panier : 0 article(s) | Total : 0€");
            argentLabel.setText("Argent : " + argent + "€");

            JOptionPane.showMessageDialog(this, "Achat effectué !");
        });

        JPanel panierPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panierPanel.add(panierLabel);
        panierPanel.add(argentLabel);
        panierPanel.add(boutonAcheterPanier);

        panelBoutique.add(panierPanel, BorderLayout.SOUTH);

        // Charger les cartes au démarrage
        chargerCartes();
    }

    // ================== CHARGEMENT DES CARTES ==================

    private void chargerCartes() {

        cardsPanel.removeAll();

        String type = (String) typeSelector.getSelectedItem();

        ArrayList<Produit> produits = chargerProduits(type);

        for (Produit p : produits) {
            cardsPanel.add(creerCarte(p));
        }

        cardsPanel.revalidate();
        cardsPanel.repaint();
    }

    // ================== CREATION D'UNE CARTE ==================

    private JPanel creerCarte(Produit p) {

        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBorder(BorderFactory.createLineBorder(Color.GRAY, 2));
        card.setBackground(Color.WHITE);
        card.setPreferredSize(new Dimension(250, 300));

        JLabel titre = new JLabel(p.titre);
        titre.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titre.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel type = new JLabel("Type : " + p.type);
        type.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel desc = new JLabel("<html><p style='width:200px'>" + p.description + "</p></html>");
        desc.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel prix = new JLabel("Prix : " + p.prixAchat + "€");
        prix.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel prixLoc = new JLabel("Location : " + p.prixLocation + "€");
        prixLoc.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel age = new JLabel("Âge : " + p.ageMin + "+");
        age.setAlignmentX(Component.CENTER_ALIGNMENT);

        JButton acheter = new JButton("Acheter");
        acheter.setAlignmentX(Component.CENTER_ALIGNMENT);

        JButton louer = new JButton("Louer");
        louer.setAlignmentX(Component.CENTER_ALIGNMENT);

        acheter.addActionListener(e -> {
            nbPanier++;
            totalPanier += p.prixAchat;
            panierLabel.setText("Panier : " + nbPanier + " article(s) | Total : " + totalPanier + "€");
        });

        louer.addActionListener(e -> {
            nbPanier++;
            totalPanier += p.prixLocation;
            panierLabel.setText("Panier : " + nbPanier + " article(s) | Total : " + totalPanier + "€");
        });

        card.add(Box.createVerticalStrut(10));
        card.add(titre);
        card.add(type);
        card.add(desc);
        card.add(prix);
        card.add(prixLoc);
        card.add(age);
        card.add(Box.createVerticalStrut(10));
        card.add(acheter);
        card.add(louer);

        return card;
    }

    // ================== CHARGEMENT SQL ==================

    private ArrayList<Produit> chargerProduits(String type) {

        ArrayList<Produit> liste = new ArrayList<>();

        String typeSQL = switch (type) {
            case "Livre" -> "livre";
            case "Jeu vidéo" -> "jeu_video";
            case "Jeu société" -> "jeu_societe";
            default -> "";
        };

        String sql = "SELECT titre, description, prix_achat, prix_location, age_min, type FROM produit WHERE type = ?";

        try (Connection conn = base_de_donnee.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, typeSQL);

            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Produit p = new Produit(
                        rs.getString("titre"),
                        rs.getString("description"),
                        rs.getDouble("prix_achat"),
                        rs.getDouble("prix_location"),
                        rs.getInt("age_min"),
                        rs.getString("type")
                );
                liste.add(p);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Erreur SQL : " + e.getMessage());
        }

        return liste;
    }

    // ================== CLASSE PRODUIT ==================

    class Produit {
        String titre, description, type;
        double prixAchat, prixLocation;
        int ageMin;

        Produit(String t, String d, double pa, double pl, int age, String type) {
            this.titre = t;
            this.description = d;
            this.prixAchat = pa;
            this.prixLocation = pl;
            this.ageMin = age;
            this.type = type;
        }
    }
}
