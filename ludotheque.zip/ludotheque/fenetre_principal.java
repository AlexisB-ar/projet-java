package ludotheque;

import javax.swing.*;
import java.awt.*;

public class fenetre_principal extends JFrame {

    private JPanel panelCentre;

    public fenetre_principal() {
        setTitle("Ludothèque");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // --- HEADER ---
        JPanel header = new JPanel(new BorderLayout());
        header.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        JLabel titre = new JLabel("Bienvenue " + session.identifiant + " dans votre ludothèque", SwingConstants.CENTER);
        titre.setFont(new Font("Arial", Font.BOLD, 22));
        header.add(titre, BorderLayout.CENTER);

        JButton btnDeconnexion = new JButton("Déconnexion");
        header.add(btnDeconnexion, BorderLayout.EAST);

        add(header, BorderLayout.NORTH);

        // --- PANEL GAUCHE (ACHATS / LOCATIONS) ---
        JPanel panelGauche = new JPanel(new BorderLayout());
        panelGauche.setPreferredSize(new Dimension(300, 0));
        panelGauche.setBorder(BorderFactory.createTitledBorder("Vos achats / locations"));

        String[][] data = {
                {"Aucun", "Aucun"}
        };
        String[] colonnes = {"Produit", "Type"};

        JTable table = new JTable(data, colonnes);
        panelGauche.add(new JScrollPane(table), BorderLayout.CENTER);

        add(panelGauche, BorderLayout.WEST);

        // --- PANEL CENTRE (BOUTIQUE DIRECT) ---
        panelCentre = new JPanel(new BorderLayout());
        panelCentre.add(new boutique(), BorderLayout.CENTER); // <-- Boutique affichée direct
        add(panelCentre, BorderLayout.CENTER);

        // --- PANEL ADMIN ---
        if ("admin".equals(session.role)) {
            JPanel panelAdmin = new JPanel(new GridLayout(4, 1, 10, 10));
            panelAdmin.setBorder(BorderFactory.createTitledBorder("Administration"));

            JButton btnAjouter = new JButton("Ajouter un produit");
            JButton btnModifier = new JButton("Modifier un produit");
            JButton btnSupprimer = new JButton("Supprimer un produit");
            JButton btnGestionUsers = new JButton("Gérer les utilisateurs");

            panelAdmin.add(btnAjouter);
            panelAdmin.add(btnModifier);
            panelAdmin.add(btnSupprimer);
            panelAdmin.add(btnGestionUsers);

            add(panelAdmin, BorderLayout.EAST);
        }

        // --- ACTIONS ---
        btnDeconnexion.addActionListener(e -> {
            session.idUtilisateur = 0;
            session.identifiant = null;
            session.role = null;
            dispose();
            new fenetre_user();
        });

        // --- PLEIN ÉCRAN ---
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setVisible(true);
    }
}
