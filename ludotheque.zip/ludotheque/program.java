package ludotheque;

public class program {
    public static void main(String[] args) {
    	new fenetre_user();

    }
    
}

 