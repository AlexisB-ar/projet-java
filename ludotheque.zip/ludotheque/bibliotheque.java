package ludotheque;

import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class bibliotheque extends JFrame {

    public bibliotheque() {
        setTitle("Bibliothèque");
        setSize(1000, 800);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JLabel titre = new JLabel("Bienvenue dans votre bibliothèque", SwingConstants.CENTER);
        titre.setFont(new Font("Arial", Font.BOLD, 24));
        add(titre, BorderLayout.NORTH);

        JPanel contenu = new JPanel();
        contenu.setLayout(new BoxLayout(contenu, BoxLayout.Y_AXIS));

        contenu.add(new JLabel("Ici, vous retrouvez tous les jeux vidéo, jeux de société et livres achetés ou loués :"));

        JComboBox<String> titreBox = new JComboBox<>();
        contenu.add(titreBox);

        // Chargement des titres depuis la base
        chargerTitres(titreBox);

        add(contenu, BorderLayout.CENTER);

        setVisible(true);
    }

    private void chargerTitres(JComboBox<String> combo) {

        String sql = "SELECT titre FROM produit";

        try (Connection conn = base_de_donnee.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                combo.addItem(rs.getString("titre"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this,
                    "Erreur SQL : " + e.getMessage(),
                    "Erreur",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(bibliotheque::new);
    }
}
