package ludotheque;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class base_de_donnee {

    private static final String URL = "jdbc:mysql://localhost:8889/projet_java?serverTimezone=UTC";
    private static final String LOGIN = "root";
    private static final String PASSWORD = "root";

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, LOGIN, PASSWORD);
    }
}
