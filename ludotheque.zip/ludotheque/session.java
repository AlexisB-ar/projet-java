package ludotheque;

public class session {
    public static int idUtilisateur;
    public static String identifiant;
    public static String role;
}

