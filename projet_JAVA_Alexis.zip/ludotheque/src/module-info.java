/**
 * 
 */
/**
 * 
 */
module ludotheque {
	requires java.sql;
	requires java.desktop;
}