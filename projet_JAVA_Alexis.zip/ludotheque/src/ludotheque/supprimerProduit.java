package ludotheque;

import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.util.ArrayList;

public class supprimerProduit extends JFrame {

    private JComboBox<String> comboType;
    private JComboBox<String> comboProduit;

    private ArrayList<Integer> listeIds = new ArrayList<>();

    public supprimerProduit() {

        setTitle("Supprimer un produit");
        setSize(500, 250);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(4, 2, 10, 10));


        add(new JLabel("Type de produit :"));
        comboType = new JComboBox<>(new String[]{"livre", "jeu_video", "jeu_societe"});
        add(comboType);


        add(new JLabel("Produit à supprimer :"));
        comboProduit = new JComboBox<>();
        add(comboProduit);


        JButton btnSupprimer = new JButton("Supprimer");
        JButton btnAnnuler = new JButton("Annuler");

        add(btnSupprimer);
        add(btnAnnuler);


        comboType.addActionListener(e -> chargerProduits());
        btnSupprimer.addActionListener(e -> supprimerProduitSelectionne());
        btnAnnuler.addActionListener(e -> dispose());

        chargerProduits();

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setVisible(true);
    }


    private void chargerProduits() {

        comboProduit.removeAllItems();
        listeIds.clear();

        String type = (String) comboType.getSelectedItem();

        String sql = switch (type) {
            case "livre" -> "SELECT id_produit, titre FROM livre";
            case "jeu_video" -> "SELECT id_produit, titre FROM jeu_video";
            case "jeu_societe" -> "SELECT id_produit, titre FROM jeu_societe";
            default -> null;
        };

        try (Connection conn = base_de_donnee.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                int id = rs.getInt("id_produit");
                String titre = rs.getString("titre");

                listeIds.add(id);
                comboProduit.addItem(titre);
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Erreur SQL : " + ex.getMessage());
        }
    }


    private void supprimerProduitSelectionne() {

        int index = comboProduit.getSelectedIndex();

        if (index == -1) {
            JOptionPane.showMessageDialog(this, "Aucun produit sélectionné.");
            return;
        }

        int idProduit = listeIds.get(index);

        try (Connection conn = base_de_donnee.getConnection()) {

            conn.setAutoCommit(false);


            try (PreparedStatement stmt = conn.prepareStatement(
                    "DELETE FROM avis WHERE id_produit = ?")) {
                stmt.setInt(1, idProduit);
                stmt.executeUpdate();
            }


            try (PreparedStatement stmt = conn.prepareStatement(
                    "DELETE FROM acheter WHERE id_exemplaire IN (SELECT id_exemplaire FROM exemplaire WHERE id_produit = ?)")) {
                stmt.setInt(1, idProduit);
                stmt.executeUpdate();
            }


            try (PreparedStatement stmt = conn.prepareStatement(
                    "DELETE FROM location WHERE id_exemplaire IN (SELECT id_exemplaire FROM exemplaire WHERE id_produit = ?)")) {
                stmt.setInt(1, idProduit);
                stmt.executeUpdate();
            }


            try (PreparedStatement stmt = conn.prepareStatement(
                    "DELETE FROM exemplaire WHERE id_produit = ?")) {
                stmt.setInt(1, idProduit);
                stmt.executeUpdate();
            }


            try (PreparedStatement stmt = conn.prepareStatement(
                    "DELETE FROM developpe WHERE id_jeu_video IN (SELECT id_jeu_video FROM jeu_video WHERE id_produit = ?)")) {
                stmt.setInt(1, idProduit);
                stmt.executeUpdate();
            }


            try (PreparedStatement stmt = conn.prepareStatement(
                    "DELETE FROM accueil WHERE id_jeu_video IN (SELECT id_jeu_video FROM jeu_video WHERE id_produit = ?)")) {
                stmt.setInt(1, idProduit);
                stmt.executeUpdate();
            }


            try (PreparedStatement stmt = conn.prepareStatement(
                    "DELETE FROM jeu_video WHERE id_produit = ?")) {
                stmt.setInt(1, idProduit);
                stmt.executeUpdate();
            }


            try (PreparedStatement stmt = conn.prepareStatement(
                    "DELETE FROM studio WHERE id_studio NOT IN (SELECT id_studio FROM developpe)")) {
                stmt.executeUpdate();
            }


            try (PreparedStatement stmt = conn.prepareStatement(
                    "DELETE FROM jeu_societe WHERE id_produit = ?")) {
                stmt.setInt(1, idProduit);
                stmt.executeUpdate();
            }


            try (PreparedStatement stmt = conn.prepareStatement(
                    "DELETE FROM livre WHERE id_produit = ?")) {
                stmt.setInt(1, idProduit);
                stmt.executeUpdate();
            }


            try (PreparedStatement stmt = conn.prepareStatement(
                    "DELETE FROM produit WHERE id_produit = ?")) {
                stmt.setInt(1, idProduit);
                stmt.executeUpdate();
            }

            conn.commit();

            JOptionPane.showMessageDialog(this, "Produit supprimé avec succès !");
            chargerProduits(); 

        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Erreur SQL : " + ex.getMessage());
        }
    }
}
