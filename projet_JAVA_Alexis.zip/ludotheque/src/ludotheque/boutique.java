package ludotheque;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.math.BigDecimal;
import java.util.ArrayList;

public class boutique extends JPanel {

    private JComboBox<String> typeSelector;
    private JPanel cardsPanel;

    private int nbPanier = 0;
    private BigDecimal totalPanier = BigDecimal.ZERO;

    private JLabel panierLabel;
    private JLabel argentLabel;

    private JTable panierTable;
    private DefaultTableModel panierModel;

    private BigDecimal argent;

    private ArrayList<Produit> panierProduits = new ArrayList<>();

    public boutique() {

        setLayout(new BorderLayout());

        argent = getArgentUtilisateur();

        JPanel panelPanier = new JPanel(new BorderLayout());
        panelPanier.setPreferredSize(new Dimension(300, 0));
        panelPanier.setBorder(BorderFactory.createTitledBorder("Panier"));

        panierModel = new DefaultTableModel(new Object[]{"Produit", "Type"}, 0);
        panierTable = new JTable(panierModel);

        panelPanier.add(new JScrollPane(panierTable), BorderLayout.CENTER);

        JPanel infoPanier = new JPanel(new GridLayout(3, 1));
        panierLabel = new JLabel("Panier : 0 article(s) | Total : 0.00€");
        panierLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));

        argentLabel = new JLabel("Argent : " + argent.setScale(2) + "€");
        argentLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));

        JButton boutonAcheterPanier = new JButton("Acheter le panier");
        boutonAcheterPanier.addActionListener(e -> acheterPanier());

        infoPanier.add(panierLabel);
        infoPanier.add(argentLabel);
        infoPanier.add(boutonAcheterPanier);

        panelPanier.add(infoPanier, BorderLayout.SOUTH);

        add(panelPanier, BorderLayout.WEST);

        JPanel panelBoutique = new JPanel(new BorderLayout());
        panelBoutique.setBorder(BorderFactory.createTitledBorder("Ludothèque - Catalogue"));
        add(panelBoutique, BorderLayout.CENTER);

        JPanel topPanel = new JPanel();
        topPanel.add(new JLabel("Catégorie : "));

        typeSelector = new JComboBox<>(new String[]{"Livre", "Jeu vidéo", "Jeu société"});
        typeSelector.addActionListener(e -> chargerCartes());

        topPanel.add(typeSelector);
        panelBoutique.add(topPanel, BorderLayout.NORTH);

        cardsPanel = new JPanel(new GridLayout(0, 3, 20, 20));
        cardsPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JScrollPane scroll = new JScrollPane(cardsPanel);
        panelBoutique.add(scroll, BorderLayout.CENTER);

        chargerCartes();
    }

    private BigDecimal getArgentUtilisateur() {

        String sql = "SELECT argent FROM utilisateur WHERE id_utilisateur = ?";

        try (Connection conn = base_de_donnee.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, session.idUtilisateur);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return rs.getBigDecimal("argent");
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                    "Erreur récupération argent : " + e.getMessage());
        }

        return BigDecimal.ZERO;
    }

    private void acheterPanier() {

        if (panierProduits.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Votre panier est vide !");
            return;
        }

        argent = getArgentUtilisateur();

        if (argent.compareTo(totalPanier) < 0) {
            JOptionPane.showMessageDialog(this,
                    "Vous n'avez pas assez d'argent !");
            return;
        }

        for (Produit p : panierProduits) {

            boolean ok = Achat.acheterProduit(
                    p.idProduit,
                    session.idUtilisateur,
                    session.identifiant,
                    p.categorie
            );

            if (!ok) {
                JOptionPane.showMessageDialog(this,
                        "Aucun exemplaire disponible pour : " + p.titre);
                return;
            }
        }

        argent = getArgentUtilisateur();
        argentLabel.setText("Argent : " + argent.setScale(2) + "€");

        panierProduits.clear();
        nbPanier = 0;
        totalPanier = BigDecimal.ZERO;

        panierModel.setRowCount(0);
        panierLabel.setText("Panier : 0 article(s) | Total : 0.00€");

        chargerCartes();
    }

    private void chargerCartes() {

        cardsPanel.removeAll();

        String type = (String) typeSelector.getSelectedItem();

        ArrayList<Produit> produits = chargerProduits(type);

        for (Produit p : produits) {
            cardsPanel.add(creerCarte(p));
        }

        cardsPanel.revalidate();
        cardsPanel.repaint();
    }

    private JPanel creerCarte(Produit p) {

        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBorder(BorderFactory.createLineBorder(Color.GRAY, 2));
        card.setBackground(Color.WHITE);
        card.setPreferredSize(new Dimension(250, 380));

        JLabel titre = new JLabel(p.titre);
        titre.setFont(new Font("Segoe UI", Font.BOLD, 16));
        titre.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel categorie = new JLabel("Type : " + p.type);
        categorie.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel desc = new JLabel("<html><div style='width:200px; text-align:center;'>"
                + (p.description != null ? p.description : "")
                + "</div></html>");
        desc.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel prix = new JLabel("Prix : " + p.prixAchat.setScale(2) + "€");
        prix.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel prixLoc = new JLabel("Location : " + p.prixLocation.setScale(2) + "€");
        prixLoc.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel age = new JLabel("Âge : " + (p.ageMin > 0 ? p.ageMin + "+" : "N/A"));
        age.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel stock = new JLabel("Stock : " + p.stock);
        stock.setAlignmentX(Component.CENTER_ALIGNMENT);

        JButton acheter = new JButton("Ajouter au panier");
        acheter.setAlignmentX(Component.CENTER_ALIGNMENT);

        acheter.addActionListener(e -> {
            panierProduits.add(p);
            nbPanier++;
            totalPanier = totalPanier.add(p.prixAchat);

            panierModel.addRow(new Object[]{p.titre, p.type});

            panierLabel.setText(
                    "Panier : " + nbPanier +
                            " article(s) | Total : " +
                            totalPanier.setScale(2) + "€"
            );
        });

        JButton louer = new JButton("Louer");
        louer.setAlignmentX(Component.CENTER_ALIGNMENT);

        louer.addActionListener(e -> {
            boolean ok = Location.louerProduit(p.idProduit, session.idUtilisateur);

            if (!ok) {
                JOptionPane.showMessageDialog(this,
                        "Aucun exemplaire disponible ou argent insuffisant !");
                return;
            }

            argent = getArgentUtilisateur();
            argentLabel.setText("Argent : " + argent.setScale(2) + "€");

            JOptionPane.showMessageDialog(this,
                    "Location effectuée avec succès !");

            chargerCartes();
        });

        card.add(Box.createVerticalStrut(10));
        card.add(titre);
        card.add(categorie);
        card.add(desc);
        card.add(prix);
        card.add(prixLoc);
        card.add(age);
        card.add(stock);
        card.add(Box.createVerticalStrut(10));
        card.add(acheter);
        card.add(Box.createVerticalStrut(5));
        card.add(louer);

        // --- AVIS RÉCENTS ---
        ArrayList<String> avis = getDerniersAvis(p.idProduit);

        JLabel titreAvis = new JLabel("Derniers avis :");
        titreAvis.setAlignmentX(Component.CENTER_ALIGNMENT);
        titreAvis.setFont(new Font("Segoe UI", Font.BOLD, 13));
        card.add(Box.createVerticalStrut(10));
        card.add(titreAvis);

        if (avis.isEmpty()) {
            JLabel aucun = new JLabel("Aucun avis pour ce produit.");
            aucun.setAlignmentX(Component.CENTER_ALIGNMENT);
            card.add(aucun);
        } else {
            for (String a : avis) {
                JLabel lbl = new JLabel("<html><div style='width:200px; text-align:center;'>" + a + "</div></html>");
                lbl.setAlignmentX(Component.CENTER_ALIGNMENT);
                card.add(lbl);
            }
        }

        return card;
    }

    // --- Récupère les 3 derniers avis d’un produit ---
    private ArrayList<String> getDerniersAvis(int idProduit) {

        ArrayList<String> avis = new ArrayList<>();

        String sql = "SELECT u.identifiant, a.description " +
                     "FROM avis a " +
                     "JOIN utilisateur u ON a.id_utilisateur = u.id_utilisateur " +
                     "WHERE a.id_produit = ? " +
                     "ORDER BY a.id_avis DESC LIMIT 3";

        try (Connection conn = base_de_donnee.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idProduit);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                String user = rs.getString("identifiant");
                String desc = rs.getString("description");

                avis.add(user + " : " + desc);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return avis;
    }


    private ArrayList<Produit> chargerProduits(String type) {

        ArrayList<Produit> liste = new ArrayList<>();

        String sql = switch (type) {

            case "Livre" ->
                    "SELECT p.id_produit, p.stock, l.titre, l.description, l.age, " +
                            "p.prix_achat, p.prix_location, 'Livre' AS categorie, 'Livre' AS type " +
                            "FROM produit p " +
                            "JOIN livre l ON p.id_produit = l.id_produit " +
                            "WHERE p.stock > 0";

            case "Jeu vidéo" ->
                    "SELECT p.id_produit, p.stock, jv.titre, jv.description, jv.age, " +
                            "p.prix_achat, p.prix_location, 'Jeu vidéo' AS categorie, jv.type " +
                            "FROM produit p " +
                            "JOIN jeu_video jv ON p.id_produit = jv.id_produit " +
                            "WHERE p.stock > 0";

            case "Jeu société" ->
                    "SELECT p.id_produit, p.stock, js.titre, js.description, js.age, " +
                            "p.prix_achat, p.prix_location, 'Jeu société' AS categorie, js.type " +
                            "FROM produit p " +
                            "JOIN jeu_societe js ON p.id_produit = js.id_produit " +
                            "WHERE p.stock > 0";

            default -> null;
        };

        if (sql == null) return liste;

        try (Connection conn = base_de_donnee.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {

                Produit p = new Produit(
                        rs.getInt("id_produit"),
                        rs.getString("titre"),
                        rs.getString("description"),
                        rs.getBigDecimal("prix_achat"),
                        rs.getBigDecimal("prix_location"),
                        rs.getInt("age"),
                        rs.getString("type"),
                        rs.getString("categorie"),
                        rs.getInt("stock")
                );

                liste.add(p);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                    "Erreur SQL : " + e.getMessage());
        }

        return liste;
    }

    class Produit {

        int idProduit;
        String titre;
        String description;
        String type;
        String categorie;

        BigDecimal prixAchat;
        BigDecimal prixLocation;

        int ageMin;
        int stock;

        Produit(int idProduit,
                String titre,
                String description,
                BigDecimal prixAchat,
                BigDecimal prixLocation,
                int ageMin,
                String type,
                String categorie,
                int stock) {

            this.idProduit = idProduit;
            this.titre = titre;
            this.description = description;
            this.prixAchat = prixAchat;
            this.prixLocation = prixLocation;
            this.ageMin = ageMin;
            this.type = type;
            this.categorie = categorie;
            this.stock = stock;
        }
    }
}
