package ludotheque;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.util.ArrayList;

public class gererUser extends JFrame {

    private JTable tableUsers;
    private DefaultTableModel model;

    private JComboBox<String> comboUsers;
    private JButton btnSetAdmin;
    private JButton btnDeleteUser;

    private ArrayList<Integer> userIds = new ArrayList<>();

    public gererUser() {

        setTitle("Gestion des utilisateurs");
        setSize(900, 600);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        model = new DefaultTableModel(
                new Object[]{"Utilisateur", "Rôle", "Livres", "Jeux vidéo", "Jeux société", "Total"},
                0
        );

        tableUsers = new JTable(model);
        add(new JScrollPane(tableUsers), BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel(new FlowLayout());

        comboUsers = new JComboBox<>();
        btnSetAdmin = new JButton("Mettre Admin");
        btnDeleteUser = new JButton("Supprimer utilisateur");

        bottomPanel.add(new JLabel("Utilisateur :"));
        bottomPanel.add(comboUsers);
        bottomPanel.add(btnSetAdmin);
        bottomPanel.add(btnDeleteUser);

        add(bottomPanel, BorderLayout.SOUTH);

        btnSetAdmin.addActionListener(e -> setAdmin());
        btnDeleteUser.addActionListener(e -> deleteUser());

        chargerUtilisateurs();

        setVisible(true);
    }


    private void chargerUtilisateurs() {

        model.setRowCount(0);
        comboUsers.removeAllItems();
        userIds.clear();

        String sql = "SELECT id_utilisateur, identifiant, role FROM utilisateur";

        try (Connection conn = base_de_donnee.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {

                int id = rs.getInt("id_utilisateur");
                String identifiant = rs.getString("identifiant");
                String role = rs.getString("role");

                int livres = countLivres(id);
                int jeuxVideo = countJeuxVideo(id);
                int jeuxSociete = countJeuxSociete(id);

                int total = livres + jeuxVideo + jeuxSociete;

                model.addRow(new Object[]{
                        identifiant,
                        role,
                        livres,
                        jeuxVideo,
                        jeuxSociete,
                        total
                });

                comboUsers.addItem(identifiant);
                userIds.add(id);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Erreur SQL : " + e.getMessage());
        }
    }


    private int countLivres(int idUser) {

    	String sql =
    		    "SELECT COUNT(*) AS total " +
    		    "FROM acheter a " +
    		    "JOIN exemplaire e ON a.id_exemplaire = e.id_exemplaire " +
    		    "JOIN livre l ON l.id_produit = e.id_produit " +
    		    "WHERE a.id_utilisateur = ?";


        try (Connection conn = base_de_donnee.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idUser);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) return rs.getInt("total");

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return 0;
    }


    private int countJeuxVideo(int idUser) {

    	String sql =
    		    "SELECT COUNT(*) AS total " +
    		    "FROM acheter a " +
    		    "JOIN exemplaire e ON a.id_exemplaire = e.id_exemplaire " +
    		    "JOIN jeu_video jv ON jv.id_produit = e.id_produit " +
    		    "WHERE a.id_utilisateur = ?";


        try (Connection conn = base_de_donnee.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idUser);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) return rs.getInt("total");

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return 0;
    }


    private int countJeuxSociete(int idUser) {

    	String sql =
    		    "SELECT COUNT(*) AS total " +
    		    "FROM acheter a " +
    		    "JOIN exemplaire e ON a.id_exemplaire = e.id_exemplaire " +
    		    "JOIN jeu_societe js ON js.id_produit = e.id_produit " +
    		    "WHERE a.id_utilisateur = ?";


        try (Connection conn = base_de_donnee.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idUser);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) return rs.getInt("total");

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return 0;
    }


    private void setAdmin() {

        int index = comboUsers.getSelectedIndex();
        if (index == -1) return;

        int idUser = userIds.get(index);

        String sql = "UPDATE utilisateur SET role = 'admin' WHERE id_utilisateur = ?";

        try (Connection conn = base_de_donnee.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idUser);
            stmt.executeUpdate();

            JOptionPane.showMessageDialog(this, "Utilisateur mis admin !");
            chargerUtilisateurs();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Erreur SQL : " + e.getMessage());
        }
    }


    private void deleteUser() {

        int index = comboUsers.getSelectedIndex();
        if (index == -1) return;

        int idUser = userIds.get(index);

        int confirm = JOptionPane.showConfirmDialog(
                this,
                "Voulez-vous vraiment supprimer cet utilisateur ?",
                "Confirmation",
                JOptionPane.YES_NO_OPTION
        );

        if (confirm != JOptionPane.YES_OPTION) return;

        String sql = "DELETE FROM utilisateur WHERE id_utilisateur = ?";

        try (Connection conn = base_de_donnee.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idUser);
            stmt.executeUpdate();

            JOptionPane.showMessageDialog(this, "Utilisateur supprimé !");
            chargerUtilisateurs();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Erreur SQL : " + e.getMessage());
        }
    }
}
