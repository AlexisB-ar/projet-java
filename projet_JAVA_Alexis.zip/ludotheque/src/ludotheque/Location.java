package ludotheque;

import java.sql.*;
import java.math.BigDecimal;

public class Location {

    public static boolean louerProduit(int idProduit, int idUtilisateur) {

        String sqlFindEx =
            "SELECT e.id_exemplaire " +
            "FROM exemplaire e " +
            "LEFT JOIN location l ON l.id_exemplaire = e.id_exemplaire " +
            "    AND l.date_fin >= NOW() " +
            "WHERE e.id_produit = ? " +
            "AND e.estAchete = FALSE " +
            "AND l.id_location IS NULL " +
            "LIMIT 1";

        String sqlPrix =
            "SELECT prix_location FROM produit WHERE id_produit = ?";

        String sqlArgent =
            "SELECT argent FROM utilisateur WHERE id_utilisateur = ?";

        String sqlUpdateArgent =
            "UPDATE utilisateur SET argent = argent - ? WHERE id_utilisateur = ?";

        String sqlInsertLoc =
            "INSERT INTO location (id_exemplaire, id_utilisateur, date_debut, date_fin, prix_location) " +
            "VALUES (?, ?, NOW(), DATE_ADD(NOW(), INTERVAL 7 DAY), ?)";

        String sqlUpdateStock =
            "UPDATE produit SET stock = stock - 1 WHERE id_produit = ?";

        try (Connection conn = base_de_donnee.getConnection()) {

            conn.setAutoCommit(false);

            PreparedStatement stmtFind = conn.prepareStatement(sqlFindEx);
            stmtFind.setInt(1, idProduit);
            ResultSet rs = stmtFind.executeQuery();

            if (!rs.next()) {
                conn.rollback();
                return false;
            }

            int idExemplaire = rs.getInt("id_exemplaire");

            PreparedStatement stmtPrix = conn.prepareStatement(sqlPrix);
            stmtPrix.setInt(1, idProduit);
            ResultSet rsPrix = stmtPrix.executeQuery();
            rsPrix.next();
            BigDecimal prixLoc = rsPrix.getBigDecimal("prix_location");

            PreparedStatement stmtArg = conn.prepareStatement(sqlArgent);
            stmtArg.setInt(1, idUtilisateur);
            ResultSet rsArg = stmtArg.executeQuery();
            rsArg.next();
            BigDecimal argent = rsArg.getBigDecimal("argent");

            if (argent.compareTo(prixLoc) < 0) {
                conn.rollback();
                return false;
            }

            PreparedStatement stmtUpdateArg = conn.prepareStatement(sqlUpdateArgent);
            stmtUpdateArg.setBigDecimal(1, prixLoc);
            stmtUpdateArg.setInt(2, idUtilisateur);
            stmtUpdateArg.executeUpdate();

            PreparedStatement stmtLoc = conn.prepareStatement(sqlInsertLoc);
            stmtLoc.setInt(1, idExemplaire);
            stmtLoc.setInt(2, idUtilisateur);
            stmtLoc.setBigDecimal(3, prixLoc);
            stmtLoc.executeUpdate();

            PreparedStatement stmtStock = conn.prepareStatement(sqlUpdateStock);
            stmtStock.setInt(1, idProduit);
            stmtStock.executeUpdate();

            conn.commit();
            return true;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
