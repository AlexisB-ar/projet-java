package ludotheque;

import java.sql.*;
import javax.swing.JOptionPane;

public class vendre {

    public static boolean vendreExemplaire(int idExemplaire, int idUtilisateur) {

        String sqlGetProduit =
            "SELECT e.id_produit, p.prix_achat " +
            "FROM exemplaire e " +
            "JOIN produit p ON e.id_produit = p.id_produit " +
            "WHERE e.id_exemplaire = ?";

        String sqlCheckAchat =
            "SELECT * FROM acheter " +
            "WHERE id_exemplaire = ? AND id_utilisateur = ?";

        String sqlDeleteAchat =
            "DELETE FROM acheter WHERE id_exemplaire = ? AND id_utilisateur = ?";

        String sqlDeleteEx =
            "DELETE FROM exemplaire WHERE id_exemplaire = ?";

        String sqlUpdateStock =
            "UPDATE produit SET stock = stock + 1 WHERE id_produit = ?";

        String sqlUpdateArgent =
            "UPDATE utilisateur SET argent = argent + ? WHERE id_utilisateur = ?";

        try (Connection conn = base_de_donnee.getConnection()) {

            conn.setAutoCommit(false);

            PreparedStatement stmtCheck = conn.prepareStatement(sqlCheckAchat);
            stmtCheck.setInt(1, idExemplaire);
            stmtCheck.setInt(2, idUtilisateur);
            ResultSet rsCheck = stmtCheck.executeQuery();

            if (!rsCheck.next()) {
                JOptionPane.showMessageDialog(null, "Cet exemplaire ne vous appartient pas.");
                conn.rollback();
                return false;
            }

            PreparedStatement stmtProd = conn.prepareStatement(sqlGetProduit);
            stmtProd.setInt(1, idExemplaire);
            ResultSet rs = stmtProd.executeQuery();

            if (!rs.next()) {
                conn.rollback();
                return false;
            }

            int idProduit = rs.getInt("id_produit");
            double prixAchat = rs.getDouble("prix_achat");

            PreparedStatement stmtDel = conn.prepareStatement(sqlDeleteAchat);
            stmtDel.setInt(1, idExemplaire);
            stmtDel.setInt(2, idUtilisateur);
            stmtDel.executeUpdate();

            PreparedStatement stmtEx = conn.prepareStatement(sqlDeleteEx);
            stmtEx.setInt(1, idExemplaire);
            stmtEx.executeUpdate();

            PreparedStatement stmtStock = conn.prepareStatement(sqlUpdateStock);
            stmtStock.setInt(1, idProduit);
            stmtStock.executeUpdate();

            PreparedStatement stmtArgent = conn.prepareStatement(sqlUpdateArgent);
            stmtArgent.setDouble(1, prixAchat);
            stmtArgent.setInt(2, idUtilisateur);
            stmtArgent.executeUpdate();

            conn.commit();
            return true;

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erreur SQL : " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
}
