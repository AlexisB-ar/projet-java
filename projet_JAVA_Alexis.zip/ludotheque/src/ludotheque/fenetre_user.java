package ludotheque;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.security.MessageDigest;

public class fenetre_user extends JFrame {

    private JTextField fieldIdentifiant;
    private JPasswordField fieldMotDePasse;
    
    public fenetre_user() {
        setTitle("Connexion / Inscription");
        setSize(400, 220);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel labelIdentifiant = new JLabel("Identifiant :");
        fieldIdentifiant = new JTextField(15);

        JLabel labelMotDePasse = new JLabel("Mot de passe :");
        fieldMotDePasse = new JPasswordField(15);

        JButton btnConnexion = new JButton("Connexion");
        JButton btnInscription = new JButton("Inscription");

        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(labelIdentifiant, gbc);

        gbc.gridx = 1;
        panel.add(fieldIdentifiant, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(labelMotDePasse, gbc);

        gbc.gridx = 1;
        panel.add(fieldMotDePasse, gbc);

        JPanel panelBoutons = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        panelBoutons.add(btnConnexion);
        panelBoutons.add(btnInscription);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        panel.add(panelBoutons, gbc);

        add(panel);

        btnConnexion.addActionListener(e -> {
            String identifiant = fieldIdentifiant.getText().trim();
            String motDePasse = new String(fieldMotDePasse.getPassword());

            if (identifiant.isEmpty() || motDePasse.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Veuillez remplir tous les champs.");
                return;
            }

            int idUtilisateur = verifierConnexion(identifiant, motDePasse);

            if (idUtilisateur != -1) {
                session.idUtilisateur = idUtilisateur;
                session.identifiant = identifiant;

                JOptionPane.showMessageDialog(this, "Connexion réussie !");
                dispose();
                new fenetre_principal();
            } else {
                if (identifiantExiste(identifiant)) {
                    JOptionPane.showMessageDialog(this, "Mot de passe incorrect.");
                } else {
                    JOptionPane.showMessageDialog(this, "Utilisateur inconnu. Utilisez le bouton Inscription.");
                }
            }
        });

        btnInscription.addActionListener(e -> {
            String identifiant = fieldIdentifiant.getText().trim();
            String motDePasse = new String(fieldMotDePasse.getPassword());

            if (identifiant.isEmpty() || motDePasse.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Veuillez remplir tous les champs.");
                return;
            }

            if (identifiantExiste(identifiant)) {
                JOptionPane.showMessageDialog(this, "Cet identifiant existe déjà, choisissez-en un autre.");
                return;
            }

            int idNew = insererUtilisateur(identifiant, motDePasse);
            if (idNew != -1) {
                session.idUtilisateur = idNew;
                session.identifiant = identifiant;
                session.role = "user";

                JOptionPane.showMessageDialog(this, "Inscription réussie, vous êtes connecté.");
                dispose();
                new fenetre_principal();
            } else {
                JOptionPane.showMessageDialog(this, "Erreur lors de l'inscription.");
            }
        });

        setVisible(true);
    }

    public int insererUtilisateur(String identifiant, String motDePasse) {

        String motDePasseHash = hashSHA256(motDePasse);
        String sql = "INSERT INTO utilisateur (identifiant, mot_de_passe, role) VALUES (?, ?, 'user')";

        try (Connection connexion = base_de_donnee.getConnection();
             PreparedStatement stmt = connexion.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setString(1, identifiant);
            stmt.setString(2, motDePasseHash);

            stmt.executeUpdate();

            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                return rs.getInt(1);
            }

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Erreur lors de l'enregistrement de l'utilisateur.");
        }
        return -1;
    }

    // HASH SHA-256
    public static String hashSHA256(String motDePasse) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(motDePasse.getBytes("UTF-8"));

            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public int verifierConnexion(String identifiant, String motDePasse) {

        String motDePasseHash = hashSHA256(motDePasse);
        String sql = "SELECT id_utilisateur, role FROM utilisateur WHERE identifiant = ? AND mot_de_passe = ?";

        try (Connection connexion = base_de_donnee.getConnection();
             PreparedStatement stmt = connexion.prepareStatement(sql)) {

            stmt.setString(1, identifiant);
            stmt.setString(2, motDePasseHash);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                session.role = rs.getString("role");
                return rs.getInt("id_utilisateur");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return -1;
    }

    public boolean identifiantExiste(String identifiant) {

        String sql = "SELECT id_utilisateur FROM utilisateur WHERE identifiant = ?";

        try (Connection connexion = base_de_donnee.getConnection();
             PreparedStatement stmt = connexion.prepareStatement(sql)) {

            stmt.setString(1, identifiant);

            ResultSet rs = stmt.executeQuery();
            return rs.next();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }


}
