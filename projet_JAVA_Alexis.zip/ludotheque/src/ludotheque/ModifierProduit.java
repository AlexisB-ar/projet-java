package ludotheque;

import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.math.BigDecimal;

public class ModifierProduit extends JFrame {

    private JComboBox<String> comboType;
    private JComboBox<ProduitItem> comboProduit;

    private JTextField fieldTitre, fieldDescription, fieldDateSortie,
            fieldPrixAchat, fieldPrixLocation, fieldAgeMin, fieldStock;

    public ModifierProduit() {

        setTitle("Modifier un produit");
        setSize(500, 550);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(11, 2, 10, 10));

        add(new JLabel("Type :"));
        comboType = new JComboBox<>(new String[]{"livre", "jeu_video", "jeu_societe"});
        add(comboType);

        add(new JLabel("Produit :"));
        comboProduit = new JComboBox<>();
        add(comboProduit);

        add(new JLabel("Titre :"));
        fieldTitre = new JTextField();
        add(fieldTitre);

        add(new JLabel("Description :"));
        fieldDescription = new JTextField();
        add(fieldDescription);

        add(new JLabel("Date (AAAA-MM-JJ) :"));
        fieldDateSortie = new JTextField();
        add(fieldDateSortie);

        add(new JLabel("Prix achat (€) :"));
        fieldPrixAchat = new JTextField();
        add(fieldPrixAchat);

        add(new JLabel("Prix location (€) :"));
        fieldPrixLocation = new JTextField();
        add(fieldPrixLocation);

        add(new JLabel("Âge minimum :"));
        fieldAgeMin = new JTextField();
        add(fieldAgeMin);

        add(new JLabel("Stock :"));
        fieldStock = new JTextField();
        add(fieldStock);

        JButton btnModifier = new JButton("Modifier");
        JButton btnAnnuler = new JButton("Annuler");

        add(btnModifier);
        add(btnAnnuler);

        comboType.addActionListener(e -> chargerProduits());
        comboProduit.addActionListener(e -> chargerInfosProduit());
        btnModifier.addActionListener(e -> modifierProduit());
        btnAnnuler.addActionListener(e -> dispose());

        chargerProduits();

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setVisible(true);
    }


    private void chargerProduits() {
        comboProduit.removeAllItems();

        String type = (String) comboType.getSelectedItem();

        String sql = switch (type) {
            case "livre" -> "SELECT id_produit, titre FROM livre";
            case "jeu_video" -> "SELECT id_produit, titre FROM jeu_video";
            case "jeu_societe" -> "SELECT id_produit, titre FROM jeu_societe";
            default -> null;
        };

        try (Connection conn = base_de_donnee.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                comboProduit.addItem(new ProduitItem(
                        rs.getInt("id_produit"),
                        rs.getString("titre")
                ));
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                    "Erreur chargement produits : " + e.getMessage());
        }
    }


    private void chargerInfosProduit() {

        ProduitItem item = (ProduitItem) comboProduit.getSelectedItem();
        if (item == null) return;

        String type = (String) comboType.getSelectedItem();

        String sql = switch (type) {

            case "livre" ->
                    "SELECT l.titre, l.description, p.date, l.age, p.prix_achat, p.prix_location, p.stock " +
                            "FROM livre l JOIN produit p ON l.id_produit = p.id_produit " +
                            "WHERE l.id_produit = ?";

            case "jeu_video" ->
                    "SELECT jv.titre, jv.description, p.date, jv.age, p.prix_achat, p.prix_location, p.stock " +
                            "FROM jeu_video jv JOIN produit p ON jv.id_produit = p.id_produit " +
                            "WHERE jv.id_produit = ?";

            case "jeu_societe" ->
                    "SELECT js.titre, js.description, p.date, js.age, p.prix_achat, p.prix_location, p.stock " +
                            "FROM jeu_societe js JOIN produit p ON js.id_produit = p.id_produit " +
                            "WHERE js.id_produit = ?";

            default -> null;
        };

        try (Connection conn = base_de_donnee.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, item.id);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                fieldTitre.setText(rs.getString("titre"));
                fieldDescription.setText(rs.getString("description"));

                Date date = rs.getDate("date");
                fieldDateSortie.setText(date != null ? date.toString() : "");

                fieldPrixAchat.setText(rs.getString("prix_achat"));
                fieldPrixLocation.setText(rs.getString("prix_location"));
                fieldAgeMin.setText(rs.getString("age"));
                fieldStock.setText(rs.getString("stock"));
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                    "Erreur chargement infos : " + e.getMessage());
        }
    }


    private void modifierProduit() {

        ProduitItem item = (ProduitItem) comboProduit.getSelectedItem();
        if (item == null) return;

        // --- Vérification des champs numériques ---
        if (fieldPrixAchat.getText().trim().isEmpty() ||
            fieldPrixLocation.getText().trim().isEmpty() ||
            fieldAgeMin.getText().trim().isEmpty() ||
            fieldStock.getText().trim().isEmpty()) {

            JOptionPane.showMessageDialog(this,
                    "Tous les champs numériques doivent être remplis !");
            return;
        }

        String type = (String) comboType.getSelectedItem();

        try (Connection conn = base_de_donnee.getConnection()) {

            conn.setAutoCommit(false);

            String titre = fieldTitre.getText().trim();
            String description = fieldDescription.getText().trim();
            String dateSortie = fieldDateSortie.getText().trim();

            int age = Integer.parseInt(fieldAgeMin.getText().trim());
            int stock = Integer.parseInt(fieldStock.getText().trim());

            BigDecimal prixAchat = new BigDecimal(fieldPrixAchat.getText().trim());
            BigDecimal prixLocation = new BigDecimal(fieldPrixLocation.getText().trim());

            // --- Mise à jour table produit ---
            String sqlProduit =
                    "UPDATE produit SET prix_achat=?, prix_location=?, date=?, stock=? WHERE id_produit=?";

            try (PreparedStatement stmt = conn.prepareStatement(sqlProduit)) {
                stmt.setBigDecimal(1, prixAchat);
                stmt.setBigDecimal(2, prixLocation);

                if (!dateSortie.isEmpty()) {
                    stmt.setDate(3, Date.valueOf(dateSortie));
                } else {
                    stmt.setNull(3, Types.DATE);
                }

                stmt.setInt(4, stock);
                stmt.setInt(5, item.id);

                stmt.executeUpdate();
            }

            // --- Mise à jour table spécifique ---
            String sqlSpec = switch (type) {
                case "livre" ->
                        "UPDATE livre SET titre=?, description=?, age=? WHERE id_produit=?";
                case "jeu_video" ->
                        "UPDATE jeu_video SET titre=?, description=?, age=? WHERE id_produit=?";
                case "jeu_societe" ->
                        "UPDATE jeu_societe SET titre=?, description=?, age=? WHERE id_produit=?";
                default -> null;
            };

            try (PreparedStatement stmt = conn.prepareStatement(sqlSpec)) {
                stmt.setString(1, titre);
                stmt.setString(2, description);
                stmt.setInt(3, age);
                stmt.setInt(4, item.id);

                stmt.executeUpdate();
            }

            conn.commit();

            JOptionPane.showMessageDialog(this,
                    "Produit modifié avec succès !");
            dispose();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Erreur modification : " + e.getMessage());
            e.printStackTrace();
        }
    }


    class ProduitItem {
        int id;
        String titre;

        ProduitItem(int id, String titre) {
            this.id = id;
            this.titre = titre;
        }

        public String toString() {
            return titre;
        }
    }
}
