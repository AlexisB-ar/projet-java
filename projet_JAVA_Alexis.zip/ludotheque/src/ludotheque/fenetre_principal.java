package ludotheque;

import javax.swing.*;
import java.awt.*;

public class fenetre_principal extends JFrame {

    private JPanel panelCentre;

    public fenetre_principal() {
        setTitle("Ludothèque");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel header = new JPanel(new BorderLayout());
        header.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        JLabel titre = new JLabel("Bienvenue " + session.identifiant + " dans votre ludothèque", SwingConstants.CENTER);
        titre.setFont(new Font("Arial", Font.BOLD, 22));
        header.add(titre, BorderLayout.CENTER);

        JButton btnBoutique = new JButton("Boutique");
        JButton btnEspace = new JButton("Votre espace");
        JButton btnDeconnexion = new JButton("Déconnexion");

        JPanel panelBoutonsDroite = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        panelBoutonsDroite.add(btnBoutique);
        panelBoutonsDroite.add(btnEspace);
        panelBoutonsDroite.add(btnDeconnexion);

        header.add(panelBoutonsDroite, BorderLayout.EAST);

        add(header, BorderLayout.NORTH);



        panelCentre = new JPanel(new BorderLayout());
        panelCentre.add(new boutique(), BorderLayout.CENTER); 
        add(panelCentre, BorderLayout.CENTER);

        if ("admin".equals(session.role)) {
            JPanel panelAdmin = new JPanel(new GridLayout(4, 1, 10, 10));
            panelAdmin.setBorder(BorderFactory.createTitledBorder("Administration"));

            JButton btnAjouter = new JButton("Ajouter un produit");
            JButton btnModifier = new JButton("Modifier un produit");
            JButton btnSupprimer = new JButton("Supprimer un produit");
            JButton btnGestionUsers = new JButton("Gérer les utilisateurs");

            btnAjouter.addActionListener(e -> new AjouterProduit());
            btnModifier.addActionListener(e->new ModifierProduit());
            btnSupprimer.addActionListener(e-> new supprimerProduit());
            btnGestionUsers.addActionListener(e-> new gererUser());

            
            panelAdmin.add(btnAjouter);
            panelAdmin.add(btnModifier);
            panelAdmin.add(btnSupprimer);
            panelAdmin.add(btnGestionUsers);

            add(panelAdmin, BorderLayout.EAST);
        }

        btnEspace.addActionListener(e -> {
            panelCentre.removeAll();
            panelCentre.add(new VotreEspace(), BorderLayout.CENTER);
            panelCentre.revalidate();
            panelCentre.repaint();
        });
        
        btnBoutique.addActionListener(e -> {
            panelCentre.removeAll();
            panelCentre.add(new boutique(), BorderLayout.CENTER);
            panelCentre.revalidate();
            panelCentre.repaint();
        });


        btnDeconnexion.addActionListener(e -> {
            session.idUtilisateur = 0;
            session.identifiant = null;
            session.role = null;
            dispose();
            new fenetre_user();
        });

        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setVisible(true);
    }
}
