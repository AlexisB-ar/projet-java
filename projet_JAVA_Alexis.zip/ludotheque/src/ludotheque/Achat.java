package ludotheque;

import java.sql.*;
import java.math.BigDecimal;

public class Achat {

    public static boolean acheterProduit(int idProduit, int idUtilisateur, String identifiant, String typeProduit) {

        String sqlCheckStock = "SELECT stock FROM produit WHERE id_produit = ?";
        String sqlGetPrix = "SELECT prix_achat FROM produit WHERE id_produit = ?";
        String sqlUpdateStock = "UPDATE produit SET stock = stock - 1 WHERE id_produit = ?";
        String sqlInsertEx = "INSERT INTO exemplaire (id_produit, estAchete) VALUES (?, TRUE)";
        String sqlInsertAch =
            "INSERT INTO acheter (id_exemplaire, id_utilisateur, identifiant, type_produit, estacheter, date_achat) " +
            "VALUES (?, ?, ?, ?, TRUE, NOW())";
        String sqlUpdateArgent = "UPDATE utilisateur SET argent = argent - ? WHERE id_utilisateur = ?";

        try (Connection conn = base_de_donnee.getConnection()) {

            conn.setAutoCommit(false);

            PreparedStatement stmtCheck = conn.prepareStatement(sqlCheckStock);
            stmtCheck.setInt(1, idProduit);
            ResultSet rs = stmtCheck.executeQuery();

            if (!rs.next()) {
                conn.rollback();
                return false;
            }

            int stock = rs.getInt("stock");
            if (stock <= 0) {
                conn.rollback();
                return false;
            }

            PreparedStatement stmtPrix = conn.prepareStatement(sqlGetPrix);
            stmtPrix.setInt(1, idProduit);
            ResultSet rsPrix = stmtPrix.executeQuery();

            if (!rsPrix.next()) {
                conn.rollback();
                return false;
            }

            BigDecimal prixAchat = rsPrix.getBigDecimal("prix_achat");

            PreparedStatement stmtUpdate = conn.prepareStatement(sqlUpdateStock);
            stmtUpdate.setInt(1, idProduit);
            stmtUpdate.executeUpdate();

            PreparedStatement stmtEx = conn.prepareStatement(sqlInsertEx, Statement.RETURN_GENERATED_KEYS);
            stmtEx.setInt(1, idProduit);
            stmtEx.executeUpdate();

            ResultSet rsEx = stmtEx.getGeneratedKeys();
            rsEx.next();
            int idExemplaire = rsEx.getInt(1);

            PreparedStatement stmtAch = conn.prepareStatement(sqlInsertAch);
            stmtAch.setInt(1, idExemplaire);
            stmtAch.setInt(2, idUtilisateur);
            stmtAch.setString(3, identifiant);
            stmtAch.setString(4, typeProduit);
            stmtAch.executeUpdate();

            PreparedStatement stmtArgent = conn.prepareStatement(sqlUpdateArgent);
            stmtArgent.setBigDecimal(1, prixAchat);
            stmtArgent.setInt(2, idUtilisateur);
            stmtArgent.executeUpdate();

            conn.commit();
            return true;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
