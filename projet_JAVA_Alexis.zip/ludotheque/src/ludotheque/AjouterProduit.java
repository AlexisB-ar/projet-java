package ludotheque;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.sql.*;
import java.math.BigDecimal;
import java.util.ArrayList;

public class AjouterProduit extends JFrame {

    private JTextField fieldTitre;
    private JTextField fieldDescription;
    private JTextField fieldDateSortie;
    private JTextField fieldPrixAchat;
    private JTextField fieldPrixLocation;
    private JTextField fieldAgeMin;

    private JTextField fieldAuteur;
    private JTextField fieldISBN;
    private JTextField fieldEditeur;
    private JTextField fieldStudio;

    private JComboBox<String> comboTypeJeu; 

    private JList<String> listPlateformes;
    private ArrayList<Integer> plateformesIds = new ArrayList<>();

    private JComboBox<String> comboType;
    private JPanel dynamicPanel;

    public AjouterProduit() {

        setTitle("Ajouter un produit");
        setSize(650, 800);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        JPanel mainPanel = new JPanel(new GridBagLayout());
        mainPanel.setBorder(new TitledBorder("Informations générales"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        int y = 0;

        gbc.gridx = 0; gbc.gridy = y;
        mainPanel.add(new JLabel("Titre :"), gbc);
        gbc.gridx = 1;
        fieldTitre = new JTextField();
        fieldTitre.setPreferredSize(new Dimension(250, 30));
        mainPanel.add(fieldTitre, gbc);
        y++;

        gbc.gridx = 0; gbc.gridy = y;
        mainPanel.add(new JLabel("Description :"), gbc);
        gbc.gridx = 1;
        fieldDescription = new JTextField();
        fieldDescription.setPreferredSize(new Dimension(250, 30));
        mainPanel.add(fieldDescription, gbc);
        y++;

        gbc.gridx = 0; gbc.gridy = y;
        mainPanel.add(new JLabel("Date (AAAA-MM-JJ) :"), gbc);
        gbc.gridx = 1;
        fieldDateSortie = new JTextField();
        fieldDateSortie.setPreferredSize(new Dimension(250, 30));
        mainPanel.add(fieldDateSortie, gbc);
        y++;

        gbc.gridx = 0; gbc.gridy = y;
        mainPanel.add(new JLabel("Type :"), gbc);
        gbc.gridx = 1;
        comboType = new JComboBox<>(new String[]{"livre", "jeu_video", "jeu_societe"});
        mainPanel.add(comboType, gbc);
        y++;

        gbc.gridx = 0; gbc.gridy = y;
        mainPanel.add(new JLabel("Prix achat (€) :"), gbc);
        gbc.gridx = 1;
        fieldPrixAchat = new JTextField();
        fieldPrixAchat.setPreferredSize(new Dimension(250, 30));
        mainPanel.add(fieldPrixAchat, gbc);
        y++;

        gbc.gridx = 0; gbc.gridy = y;
        mainPanel.add(new JLabel("Prix location (€) :"), gbc);
        gbc.gridx = 1;
        fieldPrixLocation = new JTextField();
        fieldPrixLocation.setPreferredSize(new Dimension(250, 30));
        mainPanel.add(fieldPrixLocation, gbc);
        y++;

        gbc.gridx = 0; gbc.gridy = y;
        mainPanel.add(new JLabel("Âge minimum :"), gbc);
        gbc.gridx = 1;
        fieldAgeMin = new JTextField();
        fieldAgeMin.setPreferredSize(new Dimension(250, 30));
        mainPanel.add(fieldAgeMin, gbc);
        y++;

        add(mainPanel, BorderLayout.NORTH);

        dynamicPanel = new JPanel(new GridBagLayout());
        dynamicPanel.setBorder(new TitledBorder("Informations spécifiques"));
        add(dynamicPanel, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        JButton btnAjouter = new JButton("Ajouter");
        JButton btnAnnuler = new JButton("Annuler");
        buttonPanel.add(btnAjouter);
        buttonPanel.add(btnAnnuler);
        add(buttonPanel, BorderLayout.SOUTH);

        comboType.addActionListener(e -> update());
        btnAjouter.addActionListener(e -> ajouterProduit());
        btnAnnuler.addActionListener(e -> dispose());

        update();
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setVisible(true);
    }


    private void update() {

        dynamicPanel.removeAll();
        plateformesIds.clear();

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        int y = 0;

        fieldAuteur = null;
        fieldISBN = null;
        fieldStudio = null;
        fieldEditeur = null;
        listPlateformes = null;
        comboTypeJeu = null;

        String type = (String) comboType.getSelectedItem();

        switch (type) {

            case "livre" -> {
                gbc.gridx = 0; gbc.gridy = y;
                dynamicPanel.add(new JLabel("Auteur :"), gbc);
                gbc.gridx = 1;
                fieldAuteur = new JTextField();
                fieldAuteur.setPreferredSize(new Dimension(250, 30));
                dynamicPanel.add(fieldAuteur, gbc);
                y++;

                gbc.gridx = 0; gbc.gridy = y;
                dynamicPanel.add(new JLabel("ISBN :"), gbc);
                gbc.gridx = 1;
                fieldISBN = new JTextField();
                fieldISBN.setPreferredSize(new Dimension(250, 30));
                dynamicPanel.add(fieldISBN, gbc);
            }

            case "jeu_video" -> {

                gbc.gridx = 0; gbc.gridy = y;
                dynamicPanel.add(new JLabel("Type du jeu :"), gbc);
                gbc.gridx = 1;
                comboTypeJeu = new JComboBox<>(new String[]{
                        "Action", "Aventure", "RPG", "Stratégie", "Simulation", "Sport", "Course", "Puzzle"
                });
                dynamicPanel.add(comboTypeJeu, gbc);
                y++;

                gbc.gridx = 0; gbc.gridy = y;
                dynamicPanel.add(new JLabel("Studio :"), gbc);
                gbc.gridx = 1;
                fieldStudio = new JTextField();
                fieldStudio.setPreferredSize(new Dimension(250, 30));
                dynamicPanel.add(fieldStudio, gbc);
                y++;

                gbc.gridx = 0; gbc.gridy = y;
                dynamicPanel.add(new JLabel("Plateformes :"), gbc);

                gbc.gridx = 1;
                listPlateformes = new JList<>(chargerPlateformes());
                listPlateformes.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
                JScrollPane scroll = new JScrollPane(listPlateformes);
                scroll.setPreferredSize(new Dimension(250, 100));
                dynamicPanel.add(scroll, gbc);
            }

            case "jeu_societe" -> {

                gbc.gridx = 0; gbc.gridy = y;
                dynamicPanel.add(new JLabel("Type du jeu :"), gbc);
                gbc.gridx = 1;
                comboTypeJeu = new JComboBox<>(new String[]{
                        "Famille", "Stratégie", "Ambiance", "Coopératif", "Enfant", "Expert"
                });
                dynamicPanel.add(comboTypeJeu, gbc);
                y++;

                gbc.gridx = 0; gbc.gridy = y;
                dynamicPanel.add(new JLabel("Éditeur :"), gbc);
                gbc.gridx = 1;
                fieldEditeur = new JTextField();
                fieldEditeur.setPreferredSize(new Dimension(250, 30));
                dynamicPanel.add(fieldEditeur, gbc);
            }
        }

        dynamicPanel.revalidate();
        dynamicPanel.repaint();
    }


    private String[] chargerPlateformes() {

        ArrayList<String> noms = new ArrayList<>();
        plateformesIds.clear();

        try (Connection conn = base_de_donnee.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT id_plateforme, nom FROM plateforme");
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                plateformesIds.add(rs.getInt("id_plateforme"));
                noms.add(rs.getString("nom"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return noms.toArray(new String[0]);
    }


    private void ajouterProduit() {

        try (Connection conn = base_de_donnee.getConnection()) {

            conn.setAutoCommit(false);

            String titre = fieldTitre.getText().trim();
            String description = fieldDescription.getText().trim();
            String dateSortie = fieldDateSortie.getText().trim();
            String type = (String) comboType.getSelectedItem();

            if (titre.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Le titre est obligatoire.");
                return;
            }

            BigDecimal prixAchat = new BigDecimal(fieldPrixAchat.getText().trim());
            BigDecimal prixLocation = new BigDecimal(fieldPrixLocation.getText().trim());
            int ageMin = Integer.parseInt(fieldAgeMin.getText().trim());

            Date sqlDate = null;
            if (!dateSortie.isEmpty()) sqlDate = Date.valueOf(dateSortie);

            String sqlProduit = "INSERT INTO produit (prix_achat, prix_location, duree_moyenne, date, stock) VALUES (?, ?, NULL, ?, 1)";
            int idProduit;

            try (PreparedStatement stmt = conn.prepareStatement(sqlProduit, Statement.RETURN_GENERATED_KEYS)) {
                stmt.setBigDecimal(1, prixAchat);
                stmt.setBigDecimal(2, prixLocation);
                if (sqlDate != null) stmt.setDate(3, sqlDate);
                else stmt.setNull(3, Types.DATE);
                stmt.executeUpdate();

                ResultSet rs = stmt.getGeneratedKeys();
                rs.next();
                idProduit = rs.getInt(1);
            }

            switch (type) {

                case "livre" -> {
                    String sql = "INSERT INTO livre (id_produit, titre, description, age, auteur, isbn) VALUES (?, ?, ?, ?, ?, ?)";
                    try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                        stmt.setInt(1, idProduit);
                        stmt.setString(2, titre);
                        stmt.setString(3, description);
                        stmt.setInt(4, ageMin);
                        stmt.setString(5, fieldAuteur.getText().trim());
                        stmt.setString(6, fieldISBN.getText().trim());
                        stmt.executeUpdate();
                    }
                }

                case "jeu_video" -> {

                    String sqlJV = "INSERT INTO jeu_video (id_produit, titre, description, type, age) VALUES (?, ?, ?, ?, ?)";
                    int idJeuVideo;

                    try (PreparedStatement stmt = conn.prepareStatement(sqlJV, Statement.RETURN_GENERATED_KEYS)) {
                        stmt.setInt(1, idProduit);
                        stmt.setString(2, titre);
                        stmt.setString(3, description);
                        stmt.setString(4, comboTypeJeu.getSelectedItem().toString());
                        stmt.setInt(5, ageMin);
                        stmt.executeUpdate();

                        ResultSet rs = stmt.getGeneratedKeys();
                        rs.next();
                        idJeuVideo = rs.getInt(1);
                    }

                    String studioNom = fieldStudio.getText().trim();
                    int idStudio;

                    String checkStudio = "SELECT id_studio FROM studio WHERE nom = ?";
                    try (PreparedStatement stmt = conn.prepareStatement(checkStudio)) {
                        stmt.setString(1, studioNom);
                        ResultSet rs = stmt.executeQuery();

                        if (rs.next()) {
                            idStudio = rs.getInt("id_studio");
                        } else {
                            String insertStudio = "INSERT INTO studio (nom) VALUES (?)";
                            try (PreparedStatement insertStmt = conn.prepareStatement(insertStudio, Statement.RETURN_GENERATED_KEYS)) {
                                insertStmt.setString(1, studioNom);
                                insertStmt.executeUpdate();
                                ResultSet rs2 = insertStmt.getGeneratedKeys();
                                rs2.next();
                                idStudio = rs2.getInt(1);
                            }
                        }
                    }

                    String sqlDeveloppe = "INSERT INTO developpe (id_jeu_video, id_studio) VALUES (?, ?)";
                    try (PreparedStatement stmt = conn.prepareStatement(sqlDeveloppe)) {
                        stmt.setInt(1, idJeuVideo);
                        stmt.setInt(2, idStudio);
                        stmt.executeUpdate();
                    }

                    int[] selected = listPlateformes.getSelectedIndices();
                    for (int index : selected) {
                        int idPlateforme = plateformesIds.get(index);

                        String sqlAccueil = "INSERT INTO accueil (id_jeu_video, id_plateforme) VALUES (?, ?)";
                        try (PreparedStatement stmt = conn.prepareStatement(sqlAccueil)) {
                            stmt.setInt(1, idJeuVideo);
                            stmt.setInt(2, idPlateforme);
                            stmt.executeUpdate();
                        }
                    }
                }

                case "jeu_societe" -> {
                    String sql = "INSERT INTO jeu_societe (id_produit, titre, editeur, age, description, type) VALUES (?, ?, ?, ?, ?, ?)";
                    try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                        stmt.setInt(1, idProduit);
                        stmt.setString(2, titre);
                        stmt.setString(3, fieldEditeur.getText().trim());
                        stmt.setInt(4, ageMin);
                        stmt.setString(5, description);
                        stmt.setString(6, comboTypeJeu.getSelectedItem().toString());
                        stmt.executeUpdate();
                    }
                }
            }

            String sqlExemplaire = "INSERT INTO exemplaire (id_produit, estAchete) VALUES (?, 0)";
            try (PreparedStatement stmt = conn.prepareStatement(sqlExemplaire)) {
                stmt.setInt(1, idProduit);
                stmt.executeUpdate();
            }

            conn.commit();
            JOptionPane.showMessageDialog(this, "Produit ajouté avec succès !");
            dispose();

        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Erreur SQL : " + ex.getMessage());
        }
    }
}
