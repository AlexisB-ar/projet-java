package ludotheque;

import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.util.ArrayList;

public class VotreEspace extends JPanel {

    private JTable tableAchats;
    private JTable tableLocations;

    private ArrayList<Integer> listeIdExemplairesAchats = new ArrayList<>();
    private ArrayList<Integer> listeIdExemplairesLocations = new ArrayList<>();

    public VotreEspace() {

        setLayout(new GridLayout(2, 1, 10, 10));
        setBorder(BorderFactory.createTitledBorder("Votre espace"));

        add(creerPanelAchats());
        add(creerPanelLocations());
    }

    private void refresh() {

        removeAll();

        listeIdExemplairesAchats.clear();
        listeIdExemplairesLocations.clear();

        setLayout(new GridLayout(2, 1, 10, 10));

        add(creerPanelAchats());
        add(creerPanelLocations());

        revalidate();
        repaint();
    }

    private JPanel creerPanelAchats() {

        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createTitledBorder("Vos achats"));

        ArrayList<String[]> achats = new ArrayList<>();

        String sql =
            "SELECT a.id_exemplaire, a.date_achat, a.type_produit, " +
            "       COALESCE(l.titre, jv.titre, js.titre) AS titre " +
            "FROM acheter a " +
            "LEFT JOIN exemplaire e ON a.id_exemplaire = e.id_exemplaire " +
            "LEFT JOIN livre l ON e.id_produit = l.id_produit " +
            "LEFT JOIN jeu_video jv ON e.id_produit = jv.id_produit " +
            "LEFT JOIN jeu_societe js ON e.id_produit = js.id_produit " +
            "WHERE a.id_utilisateur = ? " +
            "ORDER BY a.date_achat DESC";

        try (Connection conn = base_de_donnee.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, session.idUtilisateur);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {

                int idEx = rs.getInt("id_exemplaire");
                listeIdExemplairesAchats.add(idEx);

                String titre = rs.getString("titre");
                String type = rs.getString("type_produit");
                String date = rs.getString("date_achat");

                achats.add(new String[]{titre, type, date});
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        JLabel lblAchats = new JLabel("Nombre de produits achetés : " + achats.size());
        lblAchats.setFont(new Font("Arial", Font.BOLD, 16));
        panel.add(lblAchats, BorderLayout.NORTH);

        String[] colonnes = {"Titre", "Type", "Date d'achat"};
        String[][] data = achats.toArray(new String[0][]);

        tableAchats = new JTable(data, colonnes);
        panel.add(new JScrollPane(tableAchats), BorderLayout.CENTER);

        JButton btnVendre = new JButton("Vendre produit");
        btnVendre.addActionListener(e -> vendreProduitSelectionne());

        JButton btnAvis = new JButton("Laisser un avis");
        btnAvis.addActionListener(e -> laisserAvis(tableAchats, listeIdExemplairesAchats));

        JPanel panelBtn = new JPanel();
        panelBtn.add(btnVendre);
        panelBtn.add(btnAvis);

        panel.add(panelBtn, BorderLayout.SOUTH);

        return panel;
    }

    private JPanel creerPanelLocations() {

        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createTitledBorder("Vos locations"));

        ArrayList<String[]> locations = new ArrayList<>();

        String sql =
            "SELECT l.id_exemplaire, l.date_debut, l.date_fin, l.prix_location, " +
            "       COALESCE(li.titre, jv.titre, js.titre) AS titre, " +
            "       CASE " +
            "           WHEN li.id_produit IS NOT NULL THEN 'Livre' " +
            "           WHEN jv.id_produit IS NOT NULL THEN 'Jeu vidéo' " +
            "           WHEN js.id_produit IS NOT NULL THEN 'Jeu société' " +
            "       END AS type " +
            "FROM location l " +
            "LEFT JOIN exemplaire e ON l.id_exemplaire = e.id_exemplaire " +
            "LEFT JOIN livre li ON e.id_produit = li.id_produit " +
            "LEFT JOIN jeu_video jv ON e.id_produit = jv.id_produit " +
            "LEFT JOIN jeu_societe js ON e.id_produit = js.id_produit " +
            "WHERE l.id_utilisateur = ? " +
            "ORDER BY l.date_debut DESC";

        try (Connection conn = base_de_donnee.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, session.idUtilisateur);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {

                int idEx = rs.getInt("id_exemplaire");
                listeIdExemplairesLocations.add(idEx);

                String titre = rs.getString("titre");
                String type = rs.getString("type");
                String dateDebut = rs.getString("date_debut");
                String dateFin = rs.getString("date_fin");
                String prix = rs.getString("prix_location");

                locations.add(new String[]{titre, type, dateDebut, dateFin, prix});
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        JLabel lblLocations = new JLabel("Nombre de locations : " + locations.size());
        lblLocations.setFont(new Font("Arial", Font.BOLD, 16));
        panel.add(lblLocations, BorderLayout.NORTH);

        String[] colonnes = {"Titre", "Type", "Début", "Fin", "Prix"};
        String[][] data = locations.toArray(new String[0][]);

        tableLocations = new JTable(data, colonnes);
        panel.add(new JScrollPane(tableLocations), BorderLayout.CENTER);

        JButton btnRendre = new JButton("Rendre location");
        btnRendre.addActionListener(e -> rendreLocationSelectionnee());

        JButton btnAvis = new JButton("Laisser un avis");
        btnAvis.addActionListener(e -> laisserAvis(tableLocations, listeIdExemplairesLocations));

        JPanel panelBtn = new JPanel();
        panelBtn.add(btnRendre);
        panelBtn.add(btnAvis);

        panel.add(panelBtn, BorderLayout.SOUTH);

        return panel;
    }

    private void vendreProduitSelectionne() {

        int ligne = tableAchats.getSelectedRow();

        if (ligne == -1) {
            JOptionPane.showMessageDialog(this, "Sélectionnez un produit à vendre.");
            return;
        }

        int idExemplaire = listeIdExemplairesAchats.get(ligne);

        boolean ok = vendre.vendreExemplaire(idExemplaire, session.idUtilisateur);

        if (ok) {
            JOptionPane.showMessageDialog(this, "Produit vendu !");
            refresh();
        } else {
            JOptionPane.showMessageDialog(this, "Erreur lors de la vente.");
        }
    }

    private void rendreLocationSelectionnee() {

        int ligne = tableLocations.getSelectedRow();

        if (ligne == -1) {
            JOptionPane.showMessageDialog(this, "Sélectionnez une location à rendre.");
            return;
        }

        int idExemplaire = listeIdExemplairesLocations.get(ligne);

        boolean ok = rendreLocation.rendre(idExemplaire);

        if (ok) {
            JOptionPane.showMessageDialog(this, "Location rendue !");
            refresh();
        } else {
            JOptionPane.showMessageDialog(this, "Erreur lors du retour.");
        }
    }

    private void laisserAvis(JTable table, ArrayList<Integer> listeIds) {

        int ligne = table.getSelectedRow();

        if (ligne == -1) {
            JOptionPane.showMessageDialog(this, "Sélectionnez un produit pour laisser un avis.");
            return;
        }

        int idExemplaire = listeIds.get(ligne);

        JPanel panel = new JPanel(new GridLayout(4, 1));

        JTextField txtNote = new JTextField();
        JTextArea txtCommentaire = new JTextArea(5, 20);

        panel.add(new JLabel("Note (1 à 5) :"));
        panel.add(txtNote);
        panel.add(new JLabel("Commentaire :"));
        panel.add(new JScrollPane(txtCommentaire));

        int result = JOptionPane.showConfirmDialog(
                this, panel, "Laisser un avis", JOptionPane.OK_CANCEL_OPTION);

        if (result == JOptionPane.OK_OPTION) {

            int note;
            try {
                note = Integer.parseInt(txtNote.getText());
                if (note < 1 || note > 5) throw new NumberFormatException();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Note invalide.");
                return;
            }

            String commentaire = txtCommentaire.getText();

            enregistrerAvis(idExemplaire, session.idUtilisateur, note, commentaire);
        }
    }

    // 🔥 Récupère l'id_produit depuis l'id_exemplaire
    private int getIdProduitExemplaire(int idExemplaire) {
        String sql = "SELECT id_produit FROM exemplaire WHERE id_exemplaire = ?";

        try (Connection conn = base_de_donnee.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idExemplaire);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return rs.getInt("id_produit");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return -1;
    }

    // 🔥 Version compatible avec ta table SQL
    private void enregistrerAvis(int idExemplaire, int idUtilisateur, int note, String commentaire) {

        int idProduit = getIdProduitExemplaire(idExemplaire);

        if (idProduit == -1) {
            JOptionPane.showMessageDialog(this, "Impossible de trouver le produit associé.");
            return;
        }

        String description = "Note : " + note + " / Commentaire : " + commentaire;

        String sql = "INSERT INTO avis (id_utilisateur, id_produit, description) VALUES (?, ?, ?)";

        try (Connection conn = base_de_donnee.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idUtilisateur);
            stmt.setInt(2, idProduit);
            stmt.setString(3, description);

            stmt.executeUpdate();

            JOptionPane.showMessageDialog(this, "Avis enregistré !");
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Erreur lors de l'enregistrement de l'avis.");
        }
    }
}
