package ludotheque;

import java.sql.*;
import java.math.BigDecimal;

public class rendreLocation {

    public static boolean rendre(int idExemplaire) {

        String sqlFind =
            "SELECT l.prix_location, l.id_utilisateur, e.id_produit " +
            "FROM location l " +
            "JOIN exemplaire e ON l.id_exemplaire = e.id_exemplaire " +
            "WHERE l.id_exemplaire = ?";

        String sqlDelete = "DELETE FROM location WHERE id_exemplaire = ?";
        String sqlUpdateStock = "UPDATE produit SET stock = stock + 1 WHERE id_produit = ?";
        String sqlRembourse = "UPDATE utilisateur SET argent = argent + ? WHERE id_utilisateur = ?";

        try (Connection conn = base_de_donnee.getConnection()) {

            conn.setAutoCommit(false);

            try (PreparedStatement stmtFind = conn.prepareStatement(sqlFind)) {

                stmtFind.setInt(1, idExemplaire);
                ResultSet rs = stmtFind.executeQuery();

                if (!rs.next()) {
                    conn.rollback();
                    return false;
                }

                BigDecimal prixLoc = rs.getBigDecimal("prix_location");
                int idUser = rs.getInt("id_utilisateur");
                int idProduit = rs.getInt("id_produit");

                try (PreparedStatement stmtDel = conn.prepareStatement(sqlDelete)) {
                    stmtDel.setInt(1, idExemplaire);
                    stmtDel.executeUpdate();
                }

                try (PreparedStatement stmtStock = conn.prepareStatement(sqlUpdateStock)) {
                    stmtStock.setInt(1, idProduit);
                    stmtStock.executeUpdate();
                }

                try (PreparedStatement stmtRemb = conn.prepareStatement(sqlRembourse)) {
                    stmtRemb.setBigDecimal(1, prixLoc);
                    stmtRemb.setInt(2, idUser);
                    stmtRemb.executeUpdate();
                }

                conn.commit();
                return true;
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
